import logo from './logo.svg';
import './App.css';
import "bootstrap/dist/css/bootstrap.css";
import "bootstrap/dist/js/bootstrap.js";

import { BrowserRouter, Route, Routes } from 'react-router-dom'
import ProductCard from './Componets/ProductCard';
import CartPage from './Componets/CardPage';
import Header from './Componets/Header';

import SuccessCheck from './Componets/SuccessCheck';
import View from './Componets/View';



function App() {
  return (
    <div className="App">
  
      <BrowserRouter>
      <Header/>
     <br></br>
     <br></br>
      <Routes>

    
 
    <Route exact path='/' element={<ProductCard/>}></Route>
    <Route exact path='/cart' element={<CartPage/>}></Route> 
    <Route exact path='/SuccessCheck' element={<SuccessCheck/>}></Route>
  
     </Routes>
     </BrowserRouter>
  
     
    </div>
  );
}

export default App;
