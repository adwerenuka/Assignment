import React from 'react'

function SuccessCheck() {
  return (
    <div>
      <h1>Successful checkOut</h1>
    </div>
  )
}

export default SuccessCheck