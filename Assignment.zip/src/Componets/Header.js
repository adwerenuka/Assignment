import React, { useEffect } from "react";
import { Link } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import { getCartTotal } from "../cartSlice";
import { colors } from "@mui/material";


function Header() {
    const { cart, totalQuantity } = useSelector((state) => state.allCart);

    const dispatch = useDispatch();
    useEffect(() => {
        dispatch(getCartTotal());
    }, [cart]);


    return (
        <div style={{ backgroundColor: "#80cbc4", padding: "10px" ,display:"flex" , justifyContent:"space-between"}}>
            <h3 style={{color:"white"}}>Online Course</h3>
            <Link to="/" style={{ textDecoration:"none"}}>
                <div style={{backgroundColor:"red" , padding:"8px", color:"white" }}>
                    <h5>Home</h5>
                </div>
                
                
                </Link>
            <Link to="/cart">
               
                <button type="button" class="btn btn-warning">count
                    Cart({totalQuantity})</button>
            </Link>

        </div>
    )
}

export default Header