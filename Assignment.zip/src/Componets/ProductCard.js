import React from 'react'
import { useSelector, useDispatch } from "react-redux";

import { Link, useNavigate } from 'react-router-dom';
import { addToCart } from '../cartSlice';
import Header from './Header';

function ProductCard() {
    const items = useSelector((state) => state.allCart.items);

    const dispatch = useDispatch();
    const navigate = useNavigate();


    return (
        <>

            <div className="container" >
                <div className="row">
                    {items.map((item, i) => (

                        <div className="col-sm-4 mb-5" key={i}>
                            <div className="card">
                                <img
                                    className="card-img-top"
                                    src={item.img}
                                    alt={''}
                                    height="250"
                                />
                                <div className="card-body">
                                    <h3 className="card-title">{item.title}</h3>
                                    <h3 className="card-title">Rs : {item.price}</h3>
                                    <button onClick={() => dispatch(addToCart(item))} type="button" class="btn btn-success btn-md">Add</button>
                                  

                                </div>
                            </div>
                        </div>

                    ))}
                </div>
            </div>
        </>

    )
}

export default ProductCard