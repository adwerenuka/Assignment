export default [
    {
      id: 1,
      title: "Reactjs",
      price: 8000.0,
      img: "https://www.freecodecamp.org/news/content/images/2022/04/featured.jpg",
      quantity: 1,
    },
    {
      id: 2,
      title: "Angular",
      price: 8000.0,
      img: "https://res.cloudinary.com/practicaldev/image/fetch/s--PYlGlKiN--/c_imagga_scale,f_auto,fl_progressive,h_900,q_auto,w_1600/https://dev-to-uploads.s3.amazonaws.com/i/tc7pnlyowg52jw2px5at.png",
      quantity: 1,
    },
    {
      id: 3,
      title: "HTML",
      price: 1000.0,
      img: "https://play-lh.googleusercontent.com/RslBy1o2NEBYUdRjQtUqLbN-ZM2hpks1mHPMiHMrpAuLqxeBPcFSAjo65nQHbTA53YYn",
      quantity: 1,
    },
    {
      id: 4,
      title: "CSS",
      price: 1500.0,
      img: "https://diziglobalsolution.com/wp-content/uploads/2023/04/logo-css-3-1536.png",
      quantity: 1,
    },
    {
      id: 5,
      title: "JAVA",
      price: 16000.0,
      img: "https://sandaacademy.com/wp-content/uploads/2023/02/Java-Logo.png",
      quantity: 1,
    },
  ];
  